**Pinout Summary**
- **Board:** `ESP32` (ESP32-WROOM / DevKit style)
- **Sketch:** `dropndispense_esp32.ino`

**Used Pins**
- **Serial1 RX:** `GPIO16` — Serial1 RX (connected to external Arduino TX)
- **Serial1 TX:** `GPIO17` — Serial1 TX (connected to external Arduino RX)
- **I2C SDA (Wire):** `GPIO21` — default SDA on ESP32 (used by the I2C LCD)
- **I2C SCL (Wire):** `GPIO22` — default SCL on ESP32 (used by the I2C LCD)
- **I2C Address:** `0x27` — LCD constructor uses this address; some backpacks use `0x3F`.
- **RFID (RC522) SPI pins:**
  - `MOSI` -> `GPIO23`
  - `MISO` -> `GPIO19`
  - `SCK`  -> `GPIO18`
  - `SDA(SS)` -> `GPIO5` (defined as `SS_PIN` in sketch)
  - `RST` -> `GPIO4` (defined as `RST_PIN` in sketch)
- **Power:** `3V3` and `GND` — power the LCD backpack and RC522 from `3.3V` and share GND.
- **WiFi:** no GPIOs used (internal radio)

**Connections (typical)**
- ESP32 `3V3` -> LCD `VCC`
- ESP32 `GND` -> LCD `GND`
- ESP32 `GPIO21 (SDA)` -> LCD `SDA`
- ESP32 `GPIO22 (SCL)` -> LCD `SCL`
- ESP32 `GPIO16 (RX)` -> External device `TX`
- ESP32 `GPIO17 (TX)` -> External device `RX`

**RC522 wiring**
- ESP32 `3V3` -> RC522 `VCC`
- ESP32 `GND` -> RC522 `GND`
- ESP32 `GPIO23 (MOSI)` -> RC522 `MOSI`
- ESP32 `GPIO19 (MISO)` -> RC522 `MISO`
- ESP32 `GPIO18 (SCK)`  -> RC522 `SCK`
- ESP32 `GPIO5 (SS)`    -> RC522 `SDA`/`SS` (chip select)
- ESP32 `GPIO4 (RST)`   -> RC522 `RST`
  - Note: the sketch now explicitly starts SPI on `SCK=GPIO18`, `MISO=GPIO19`, `MOSI=GPIO23` and sets `SS`/`RST` as outputs before initializing the RC522; ensure wiring matches these pins.
 - **Relays / Solenoids**
 - ESP32 `GPIO14` -> `relay_pin_money_box` (money box relay input, active HIGH). Relay `VCC` to `3V3`, `GND` to `GND`.
 - ESP32 `GPIO12` -> `relay_pin_parcel_door` (parcel door relay input, active HIGH). Relay `VCC` to `3V3`, `GND` to `GND`.

**Notes & Recommendations**
- The RC522 uses the SPI bus. On ESP32 use hardware SPI pins listed above (SCK=18, MISO=19, MOSI=23). The sketch uses `SS_PIN = 5` and `RST_PIN = 4`; change if needed.
- The LCD uses an I2C backpack (PCF8574/expander). No direct GPIOs for the individual LCD data lines are required.
- If the LCD shows nothing, run an I2C scanner to confirm the address (common addresses: `0x27`, `0x3F`). Change the constructor in `dropndispense_esp32.ino` accordingly.
- Avoid using ESP32 boot-strapping pins for additional peripherals in ways that change their state at reset: be cautious with `GPIO0`, `GPIO2`, `GPIO15`, and certain pins like `GPIO12` on some modules.
- Ensure a common ground between the ESP32 and any connected device (Arduino) to allow Serial communication to work reliably.
- Use `3.3V` to power the ESP32, the RC522 and the LCD logic. Do NOT power the RC522 or LCD from 5V without level shifting.

**Quick troubleshooting**
- No LCD text: confirm I2C address with a scanner sketch and check wiring.
- Serial1 comms not working: verify TX/RX cross-connect (ESP32 TX -> device RX, ESP32 RX -> device TX) and matching baud rate (`Serial1.begin(9600, SERIAL_8N1, 16, 17)` in the sketch).
- RFID not detected: check SPI wiring, power (RC522 can draw bursts when reading), and ensure `SS_PIN` and `RST_PIN` match the sketch.
 - Solenoid/relay not activating: verify `RELAY_PIN` in sketch matches wiring; ensure relay module VCC/GND are powered, and that the relay input is compatible with 3.3V logic (or use a driver/transistor).
 - Solenoid/relay not activating: verify relay pin constants in sketch match wiring; ensure relay module VCC/GND are powered, and that the relay input is compatible with 3.3V logic (or use a driver/transistor).
- WiFi not connecting: confirm SSID/password and that the AP is available; check `Serial` output for status messages.

**File**: `pins.md` — added to project root alongside `dropndispense_esp32.ino`
